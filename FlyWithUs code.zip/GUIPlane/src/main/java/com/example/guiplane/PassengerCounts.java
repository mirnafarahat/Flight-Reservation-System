/*
//Written by Mimi
//Modified by Mimi
 */
package com.example.guiplane;

public class PassengerCounts {
    private int adultCount;
    private int teensCount;
    private int childrenCount;
    private int infantsCount;
    private int lapChildrenCount;

    public PassengerCounts(int adultCount, int teensCount, int childrenCount, int infantsCount, int lapChildrenCount) {
        this.adultCount = adultCount;
        this.teensCount = teensCount;
        this.childrenCount = childrenCount;
        this.infantsCount = infantsCount;
        this.lapChildrenCount = lapChildrenCount;
    }

    @Override
    public String toString() {
        return "PassengerCounts{" +
                "adultCount=" + adultCount +
                ", teensCount=" + teensCount +
                ", childrenCount=" + childrenCount +
                ", infantsCount=" + infantsCount +
                ", lapChildrenCount=" + lapChildrenCount +
                '}';
    }

    public int getAdultCount() {
        return adultCount;
    }

    public int getTeensCount() {
        return teensCount;
    }

    public int getChildrenCount() {
        return childrenCount;
    }

    public int getInfantsCount() {
        return infantsCount;
    }

    public int getLapChildrenCount() {
        return lapChildrenCount;
    }
}
