module com.example.guiplane {
    requires javafx.controls;
    requires javafx.fxml;
    requires javax.mail;


    opens com.example.guiplane to javafx.fxml;
    exports com.example.guiplane;
}