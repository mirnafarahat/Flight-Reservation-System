/*
Written by Mirna
Modified by Mirna and Mimi
 */

package com.example.guiplane;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Payment extends Application {

    private int numPassengers;
    private Label totalAmountLabel;

    public static void main(String[] args) {
        launch(args);
    }

    private boolean paymentSuccessful = false;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Payment Information");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        Label passengersLabel = new Label("Number of Passengers:");
        ComboBox<Integer> passengersDropdown = new ComboBox<>();
        passengersDropdown.getItems().addAll(1, 2, 3, 4, 5);

        grid.add(passengersLabel, 0, 0);
        grid.add(passengersDropdown, 1, 0);

        Button submitButton = new Button("Submit");
        GridPane.setConstraints(submitButton, 1, 2);

        grid.getChildren().add(submitButton);

        submitButton.setOnAction(e -> {
            int numPassengers = passengersDropdown.getValue();
            getPassengerInfo(numPassengers);
        });

        Scene scene = new Scene(grid, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    static void getPassengerInfo(int numPassengers) {

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Passenger Information");
        dialog.setHeaderText("Enter information for Passengers");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        for (int i = 0; i < numPassengers; i++) {
            int passengerNumber = i + 1;

            Label firstNameLabel = new Label("First Name for Passenger " + passengerNumber + ":");
            TextField firstNameField = new TextField();
            Label lastNameLabel = new Label("Last Name for Passenger " + passengerNumber + ":");
            TextField lastNameField = new TextField();
            Label phoneNumberLabel = new Label("Phone Number for Passenger " + passengerNumber + ":");
            TextField phoneNumberField = new TextField();
            Label emailLabel = new Label("Email for Passenger " + passengerNumber + ":");
            TextField emailField = new TextField();

            grid.add(firstNameLabel, 0, i * 5);
            grid.add(firstNameField, 1, i * 5);
            grid.add(lastNameLabel, 0, i * 5 + 1);
            grid.add(lastNameField, 1, i * 5 + 1);
            grid.add(phoneNumberLabel, 0, i * 5 + 2);
            grid.add(phoneNumberField, 1, i * 5 + 2);
            grid.add(emailLabel, 0, i * 5 + 3);
            grid.add(emailField, 1, i * 5 + 3);

            addValidationListener(firstNameField, "First name");
            addValidationListener(lastNameField, "Last name");
            addValidationListener(phoneNumberField, "Phone number");
            addValidationListener(emailField, "Email");
        }

        dialog.getDialogPane().setContent(grid);

        ButtonType closeButton = new ButtonType("Submit", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().add(closeButton);

        Node submitButton = dialog.getDialogPane().lookupButton(closeButton);
        submitButton.addEventFilter(ActionEvent.ACTION, event -> {
            boolean anyFieldEmpty = grid.getChildren().stream()
                    .filter(node -> node instanceof TextField)
                    .map(node -> (TextField) node)
                    .anyMatch(textField -> textField.getText().trim().isEmpty());

            if (anyFieldEmpty) {
                showAlert("Empty Fields", "Please fill in all fields.", Alert.AlertType.ERROR);
                event.consume();

        } else {

                dialog.close();
            }
        });

        dialog.showAndWait();
    }

    private static void addValidationListener(TextField textField, String fieldName) {

        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!validatePassengerInfo(newValue, fieldName)) {
                showAlert("Invalid Information", "Please enter a valid " + fieldName + ".", Alert.AlertType.ERROR);
                textField.clear();
            }
        });
    }

    private static boolean validatePassengerInfo(String value, String fieldName) {
        switch (fieldName) {
            case "First name":
                return value.matches("[a-zA-Z]+");
            case "Last name":
                // Check if the value consists only of letters
                return value.matches("[a-zA-Z]+");
            case "Phone number":
                // Check if the value consists of digits and optional hyphens, spaces, and parentheses
                return value.matches("^[0-9-\\s()]+$");
            case "Email":
            default:
                return true;
        }
    }

    static void getPaymentInfo(int numPassengers, String tripType) {
        double totalPrice = calculateTotalPrice(numPassengers, tripType);

        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Payment Information");
        dialog.setHeaderText("Enter Payment Information");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);

        Label cardNumberLabel = new Label("Card Number:");
        TextField cardNumberField = new TextField();
        Label expirationDateLabel = new Label("Expiration Date:");
        TextField expirationDateField = new TextField();
        Label cvvCodeLabel = new Label("CVV Code:");
        TextField cvvCodeField = new TextField();
        Label cardHolderFirstNameLabel = new Label("Cardholder's First Name:");
        TextField cardHolderFirstNameField = new TextField();
        Label cardHolderLastNameLabel = new Label("Cardholder's Last Name:");
        TextField cardHolderLastNameField = new TextField();

        grid.add(cardNumberLabel, 0, 0);
        grid.add(cardNumberField, 1, 0);
        grid.add(expirationDateLabel, 0, 1);
        grid.add(expirationDateField, 1, 1);
        grid.add(cvvCodeLabel, 0, 2);
        grid.add(cvvCodeField, 1, 2);
        grid.add(cardHolderFirstNameLabel, 0, 3);
        grid.add(cardHolderFirstNameField, 1, 3);
        grid.add(cardHolderLastNameLabel, 0, 4);
        grid.add(cardHolderLastNameField, 1, 4);

        Label totalLabel = new Label("Total Amount:");
        Label totalAmountLabel = new Label();

        grid.add(totalLabel, 0, 5);
        totalAmountLabel.setText(String.format("$%.2f", totalPrice));
        grid.add(totalAmountLabel, 1, 5);

        ButtonType closeButton = new ButtonType("Submit", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().add(closeButton);

        Node submitButton = dialog.getDialogPane().lookupButton(closeButton);
        submitButton.addEventFilter(ActionEvent.ACTION, event -> {
            if (!validatePaymentInfo(cardNumberField.getText(), expirationDateField.getText(), cvvCodeField.getText(),
                    cardHolderFirstNameField.getText(), cardHolderLastNameField.getText())) {
                showAlert("Invalid Information", "Please enter valid payment information.", Alert.AlertType.ERROR);
                event.consume();
            } else {

                dialog.close();
            }

        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == closeButton) {
                totalAmountLabel.setText(String.format("$%.2f", totalPrice));
            }
            return null;
        });
        dialog.getDialogPane().setContent(grid);
        dialog.showAndWait();
    }

    private static double calculateTotalPrice(int numPassengers, String tripType) {
        int totalPrice = 0;

        if("Round Trip".equals(tripType)) {
            totalPrice = numPassengers * 2 * 75;
        }
        else {
            totalPrice = numPassengers * 75;
        }

        return totalPrice;

    }

    private static boolean validatePaymentInfo(String cardNumber, String expirationDate, String cvvCode, String cardHolderFirstName, String cardHolderLastName) {
        if (!cardNumber.matches("\\d{16}")) {
            return false;
        }

        if (!expirationDate.matches("\\d{2}/\\d{2}")) {
            return false;
        }
        if (!cvvCode.matches("\\d{3}")) {
            return false;
        }
        if (!cardHolderFirstName.matches("[a-zA-Z]+") || !cardHolderLastName.matches("[a-zA-Z]+")) {
            return false;
        }
        return true;
    }
    private static void showAlert(String title, String content, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
