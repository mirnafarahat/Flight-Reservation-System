/*
written by Mimi
modified by Mimi
 */

package com.example.guiplane;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Flight {
    private String flightID;
    private String source;
    private String destination;
    private String sourceAirport;
    private String destinationAirport;
    private LocalDate departureDate;
    private LocalTime departureTime;
    private LocalDate arrivalDate;
    private LocalTime arrivalTime;
    private int maxSeats;
    private int ticketsSold;
    private int difference;
    private int price;

    public Flight(String flightID, String source, String destination, String sourceAirport,
                  String destinationAirport, LocalDate departureDate, LocalTime departureTime,
                  LocalDate arrivalDate, LocalTime arrivalTime, int maxSeats, int ticketsSold, int difference, int price)
    {
        this.flightID = flightID;
        this.source = source;
        this.destination = destination;
        this.sourceAirport = sourceAirport;
        this.destinationAirport = destinationAirport;
        this.departureDate = departureDate;
        this.departureTime = departureTime;
        this.arrivalDate = arrivalDate;
        this.arrivalTime = arrivalTime;
        this.maxSeats = maxSeats;
        this.ticketsSold = ticketsSold;
        this.difference = difference;
        this.price = price;
    }

    public String getFlightID() {
        return flightID;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getSourceAirport() {
        return sourceAirport;
    }

    public String getDestinationAirport() {
        return destinationAirport;
    }

    public LocalDate getDepartureDate() {
        return departureDate;
    }

    public LocalTime getDepartureTime() {
        return departureTime;
    }

    public LocalDate getArrivalDate() {
        return arrivalDate;
    }

    public LocalTime getArrivalTime() {
        return arrivalTime;
    }
    public int getMaxSeats(){return maxSeats;}
    public int getTicketsSold(){return ticketsSold;}
    public int getDifference(){return difference;}
    public int getPrice(){ return price;}


    public static List<Flight> readFlightInfoFromCSV(String csvFilePath) {
        List<Flight> flightInfoList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            boolean firstLine = true;

            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length == 13) {
                    Flight flightInfo = new Flight(
                            parts[0].trim(),
                            parts[1].trim(),
                            parts[2].trim(),
                            parts[3].trim(),
                            parts[4].trim(),
                            LocalDate.parse(parts[5].trim(), dateFormatter),
                            LocalTime.parse(parts[6].trim(), timeFormatter),
                            LocalDate.parse(parts[7].trim(), dateFormatter),
                            LocalTime.parse(parts[8].trim(), timeFormatter),
                            Integer.parseInt(parts[9].trim()),
                            Integer.parseInt(parts[10].trim()),
                            Integer.parseInt(parts[11].trim()),
                            Integer.parseInt(parts[12].trim())
                    );
                    flightInfoList.add(flightInfo);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return flightInfoList;
    }



    public static void main(String[] args) {

        String csvFilePath = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/flights.csv";
        List<Flight> flightInfoList = Flight.readFlightInfoFromCSV(csvFilePath);

        for (Flight flightInfo : flightInfoList) {
            System.out.println("Flight ID: " + flightInfo.getFlightID());
            System.out.println("Source: " + flightInfo.getSource());
            System.out.println("Destination: " + flightInfo.getDestination());
            System.out.println("Departure time: " + flightInfo.getDepartureTime());
        }


    }
}