/*
//Written by Mimi
//Modified by Mimi
 */

package com.example.guiplane;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class SummaryReport extends Application {

    private Map<String, Integer> flightCounts = new HashMap<>();
    private int totalFlights = 0;
    private int totalTicketsSold = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        TextArea outputTextArea = new TextArea();
        outputTextArea.setEditable(false);

        Scene scene = new Scene(outputTextArea, 400, 300);
        primaryStage.setTitle("Summary Report");
        primaryStage.setScene(scene);
        primaryStage.show();

        generateSummaryReport(outputTextArea);
    }

    private void generateSummaryReport(TextArea outputTextArea) {
        String csvFilePath = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/reservations.csv";

        try (BufferedReader reader = new BufferedReader(new FileReader(csvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                processFlight(values);
            }
            printSummary(outputTextArea);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processFlight(String[] values) {
        totalFlights++;
        if (values.length > 9) {
            totalTicketsSold += Integer.parseInt(values[9]);
            String flightID = values[1];
            flightCounts.put(flightID, flightCounts.getOrDefault(flightID, 0) + 1);
        }
    }

    private void printSummary(TextArea outputTextArea) {
        outputTextArea.appendText("Welcome to the weekly Summary Report." + "\n");
        outputTextArea.appendText("\n");

        outputTextArea.appendText("Number of Flights: " + totalFlights + "\n");
        outputTextArea.appendText("\n");

        outputTextArea.appendText("Total Tickets Sold: " + totalTicketsSold + "\n");
        outputTextArea.appendText("\n");

        int ticketPrice = 75;
        int totalRevenue = totalTicketsSold * ticketPrice;
        outputTextArea.appendText("Total Revenue: $" + totalRevenue + "\n");
        outputTextArea.appendText("\n");

        outputTextArea.appendText("Types of Flights:\n");
        for (Map.Entry<String, Integer> entry : flightCounts.entrySet()) {
            String flightID = entry.getKey();
            int numberOfFlights = entry.getValue();
            double occupancyPercentage = (double) numberOfFlights / 142 * 100;

            outputTextArea.appendText(String.format("Flight ID %s: %d flights, Occupancy: %.2f%%\n", flightID, numberOfFlights, occupancyPercentage));
        }
    }
}
