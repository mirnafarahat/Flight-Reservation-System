/*
//Written by Mirna
// Modified by Mirna
 */

package com.example.guiplane;

public class PaymentInfo {
    private String cardNumber;
    private String expirationDate;
    private String cvvCode;
    private String cardHolderFirstName;
    private String cardHolderLastName;

    public PaymentInfo(String cardNumber, String expirationDate, String cvvCode,
                       String cardHolderFirstName, String cardHolderLastName) {
        this.cardNumber = cardNumber;
        this.expirationDate = expirationDate;
        this.cvvCode = cvvCode;
        this.cardHolderFirstName = cardHolderFirstName;
        this.cardHolderLastName = cardHolderLastName;
    }
    public String getCardNumber() {
        return cardNumber;
    }
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }
    public String getExpirationDate() {
        return expirationDate;
    }
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
    public String getCvvCode() {
        return cvvCode;
    }
    public void setCvvCode(String cvvCode) {
        this.cvvCode = cvvCode;
    }
    public String getCardHolderFirstName() {
        return cardHolderFirstName;
    }
    public void setCardHolderFirstName(String cardHolderFirstName) {
        this.cardHolderFirstName = cardHolderFirstName;
    }
    public String getCardHolderLastName() {
        return cardHolderLastName;
    }
    public void setCardHolderLastName(String cardHolderLastName) {
        this.cardHolderLastName = cardHolderLastName;
    }
}
