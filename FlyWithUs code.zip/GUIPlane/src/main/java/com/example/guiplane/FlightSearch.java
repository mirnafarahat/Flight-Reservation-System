/*
Written by Mimi
Modified by Mirna & Mimi
 */

package com.example.guiplane;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class FlightSearch extends Application {
    private TextField sourceAirportTextField;
    private TextField destinationAirportTextField;
    private static List<Flight> foundDepartureFlights;
    private static List<Flight> foundReturnFlights;
    private int adultCount;
    private int teensCount;
    private int childrenCount;
    private int infantsCount;
    private int lapChildrenCount;
    private PassengerCounts passengerCounts;

    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    public void ticketcounter(int adultCount, int teensCount, int childrenCount, int infantsCount, int lapChildrenCount)
    {
        this.passengerCounts = new PassengerCounts(adultCount, teensCount, childrenCount, infantsCount, lapChildrenCount);
    }
    public PassengerCounts getPassengerCounts() {

        return passengerCounts;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Flight Search");

        ChoiceBox<Object> tripTypeChoice = new ChoiceBox<>();
        tripTypeChoice.getItems().addAll("Round Trip", "One Way");
        tripTypeChoice.setValue("One Way"); // Default selection

        sourceAirportTextField = new TextField();
        sourceAirportTextField.setPromptText("Source Airport");

        DatePicker departureDatePicker = new DatePicker();
        departureDatePicker.setPromptText("Departure date");

        departureDatePicker.setConverter(new StringConverter<>() {
            final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });

        destinationAirportTextField = new TextField();
        destinationAirportTextField.setPromptText("Destination Airport");

        DatePicker arrivalDatePicker = new DatePicker();
        arrivalDatePicker.setPromptText("Return date");
        arrivalDatePicker.setDisable(true); // Initially disabled for one-way trip

        tripTypeChoice.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Object>() {
            @Override
            public void changed(ObservableValue<?> observable, Object oldValue, Object newValue) {
                if ("One Way".equals(newValue)) {
                    arrivalDatePicker.setDisable(true);
                    arrivalDatePicker.setValue(null); // Clear the value
                } else {
                    arrivalDatePicker.setDisable(false);
                }
            }
        });

        arrivalDatePicker.setConverter(new StringConverter<>() {
            final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        });

        Spinner<Integer> adultsSpinner = createSpinner();
        Spinner<Integer> teensSpinner = createSpinner();
        Spinner<Integer> childrenSpinner = createSpinner();
        Spinner<Integer> infantsSpinner = createSpinner();
        Spinner<Integer> lapChildrenSpinner = createSpinner();


        adultsSpinner.setEditable(true);
        teensSpinner.setEditable(true);
        childrenSpinner.setEditable(true);
        infantsSpinner.setEditable(true);
        lapChildrenSpinner.setEditable(true);

        adultsSpinner.valueProperty().addListener((observable, oldValue, newValue) -> {
        });
        teensSpinner.valueProperty().addListener((observable, oldValue, newValue) -> {
        });
        childrenSpinner.valueProperty().addListener((observable, oldValue, newValue) -> {
        });
        infantsSpinner.valueProperty().addListener((observable, oldValue, newValue) -> {
        });
        lapChildrenSpinner.valueProperty().addListener((observable, oldValue, newValue) -> {
        });

        TextArea outputTextArea = new TextArea();
        outputTextArea.setEditable(false);
        outputTextArea.setWrapText(true);

        Button searchButton = new Button("Search Flights");

        searchButton.setOnAction(e -> {

            String sourceAirport = sourceAirportTextField.getText();
            String destinationAirport = destinationAirportTextField.getText();
            LocalDate departDate = departureDatePicker.getValue();
            LocalDate arrivalDate = arrivalDatePicker.getValue();

            if ("Round Trip".equals(tripTypeChoice.getValue())) {
                searchFlights(sourceAirport, departDate, destinationAirport, arrivalDate, outputTextArea);
                returnFlights(destinationAirport, departDate, sourceAirport, arrivalDate, outputTextArea);
            } else {
                searchFlights(sourceAirport, departDate, destinationAirport, arrivalDate, outputTextArea);
            }

            adultCount = adultsSpinner.getValue();
            teensCount = teensSpinner.getValue();
            childrenCount = childrenSpinner.getValue();
            infantsCount = infantsSpinner.getValue();
            lapChildrenCount = lapChildrenSpinner.getValue();

            ticketcounter(adultCount, teensCount, childrenCount, infantsCount, lapChildrenCount);
        });

        Button selectFlightButton = new Button("Select Flight");
        selectFlightButton.setOnAction(ev -> {
            StringBuilder result = new StringBuilder();
            if ("Round Trip".equals(tripTypeChoice.getValue())) {
                if (foundDepartureFlights != null && foundReturnFlights != null) {
                    System.out.println("Departure Flights: " + foundDepartureFlights);
                    System.out.println("Return Flights: " + foundReturnFlights);

                    // Reserve the selected departure flight
                    if (!foundDepartureFlights.isEmpty()) {
                        Flight selectedDepartureFlight = foundDepartureFlights.get(0);
                        Payment.getPassengerInfo(calculateTotalPassengers());
                        Payment.getPaymentInfo(calculateTotalPassengers(),(String) tripTypeChoice.getValue());
                        FlightReservation.reserveFlight(selectedDepartureFlight, this);
                    }

                    // Reserve the selected return flight
                    if (!foundReturnFlights.isEmpty()) {
                        Flight selectedReturnFlight = foundReturnFlights.get(0);
                        FlightReservation.reserveFlight(selectedReturnFlight, this);

                    }
                } else {
                    String displayMessage = "No flights found please try again.\n";
                    result.append(displayMessage);
                }
            } else if ("One Way".equals(tripTypeChoice.getValue())) {
                if (foundDepartureFlights != null && !foundDepartureFlights.isEmpty()) {
                    System.out.println("Departure Flights: " + foundDepartureFlights);
                    Flight selectDepartureFlight = foundDepartureFlights.get(0);
                    Payment.getPassengerInfo(calculateTotalPassengers());
                    Payment.getPaymentInfo(calculateTotalPassengers(),(String) tripTypeChoice.getValue());
                    FlightReservation.reserveFlight(selectDepartureFlight, this);
                } else {
                    String displayMessage = "No flights found please try again.\n";
                    result.append(displayMessage);
                }
            }

            calculateTotalPassengers();
        });

        VBox root = new VBox(10);
        root.getChildren().addAll(sourceAirportTextField, departureDatePicker, destinationAirportTextField, arrivalDatePicker, tripTypeChoice,
                new Label("Passengers:"),
                new Label("Adults (Age 18+) :"), adultsSpinner,
                new Label("Teens (Age 12-17) :"), teensSpinner,
                new Label("Children (Age 2-11) :"), childrenSpinner,
                new Label("Infants (Age 0-4 excluding lap children:"), infantsSpinner,
                new Label("Lap Children (Age under 2) :"), lapChildrenSpinner,
                searchButton, outputTextArea, selectFlightButton);

        Scene scene = new Scene(root, 800, 800);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public int calculateTotalPassengers() {
        return adultCount + teensCount + childrenCount;
    }

    public static void searchFlights(String sourceAirport, LocalDate departDate, String destinationAirport, LocalDate returnDate, TextArea outputTextArea) {
        String csvFilePath = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/flights.csv";
        List<Flight> flightInfoList = Flight.readFlightInfoFromCSV(csvFilePath);

        StringBuilder result = new StringBuilder();
        foundDepartureFlights = new ArrayList<>();
        boolean found = false;

        for (Flight flight : flightInfoList) {
            if ((flight.getSourceAirport().equalsIgnoreCase(sourceAirport) && flight.getDestinationAirport().equalsIgnoreCase(destinationAirport)) ||
                    (flight.getSource().equalsIgnoreCase(sourceAirport) && flight.getDestination().equalsIgnoreCase(destinationAirport)) ||
                    (flight.getSourceAirport().equalsIgnoreCase(sourceAirport) && flight.getDestination().equalsIgnoreCase(destinationAirport)) ||
                    (flight.getSource().equalsIgnoreCase(sourceAirport) && flight.getDestinationAirport().equalsIgnoreCase(destinationAirport)))
            {

                if(flight.getDepartureDate().equals(departDate))
                {
                    result.append("----------Departing Flights_________\n");
                    result.append("Flight ID: ").append(flight.getFlightID()).append("\n");
                    result.append("Source: ").append(flight.getSource()).append("\n");
                    result.append("Destination: ").append(flight.getDestination()).append("\n");
                    result.append("Departure Date: ").append(flight.getDepartureDate()).append("\n");
                    result.append("Departure Time: ").append(flight.getDepartureTime()).append("\n");
                    result.append("Arrival Date: ").append(flight.getArrivalDate()).append("\n");
                    result.append("Arrival Time: ").append(flight.getArrivalTime()).append("\n");
                    result.append("Price of flight: $").append(flight.getPrice()).append("\n\n");
                    result.append("\n");
                    foundDepartureFlights.add(flight);
                    found = true;
                }
            }
        }

        if (!found) {
            result.append("No flights found for the given source and destination.");
        }
        Platform.runLater(() -> outputTextArea.setText(result.toString()));
    }// end of searchFlights

    public static void returnFlights(String destinationAirport, LocalDate returnDate, String sourceAirport, LocalDate departDate, TextArea outputTextArea) {
        String csvFilePath = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/flights.csv";
        List<Flight> flightInfoList = Flight.readFlightInfoFromCSV(csvFilePath);

        StringBuilder result = new StringBuilder();
        foundReturnFlights = new ArrayList<>();
        boolean found = false;

        for (Flight flight : flightInfoList) {
            if ((flight.getSourceAirport().equalsIgnoreCase(destinationAirport) && flight.getDestinationAirport().equalsIgnoreCase(sourceAirport)) ||
                    (flight.getSource().equalsIgnoreCase(destinationAirport) && flight.getDestination().equalsIgnoreCase(sourceAirport)) ||
                    (flight.getSourceAirport().equalsIgnoreCase(destinationAirport) && flight.getDestination().equalsIgnoreCase(sourceAirport)) ||
                    (flight.getSource().equalsIgnoreCase(destinationAirport) && flight.getDestinationAirport().equalsIgnoreCase(sourceAirport)))
            {
                if (flight.getDepartureDate().equals(departDate)) {
                    // Print flight information
                    result.append("----------Return Flights_________\n");
                    result.append("Flight ID: ").append(flight.getFlightID()).append("\n");
                    result.append("Source: ").append(flight.getSource()).append("\n");
                    result.append("Destination: ").append(flight.getDestination()).append("\n");
                    result.append("Departure Date: ").append(flight.getDepartureDate()).append("\n");
                    result.append("Departure Time: ").append(flight.getDepartureTime()).append("\n");
                    result.append("Arrival Date: ").append(flight.getArrivalDate()).append("\n");
                    result.append("Arrival Time: ").append(flight.getArrivalTime()).append("\n");
                    result.append("Price of flight: $").append(flight.getPrice()).append("\n\n");
                    result.append("\n");
                    foundReturnFlights.add(flight);
                    found = true;
                }
            }
        }

        if (!found) {
            result.append("No flights found for the given source and destination.");
        }

        Platform.runLater(() -> outputTextArea.appendText(result.toString()));
    }// end of returnFlights

    private Spinner<Integer> createSpinner() {
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0);
        Spinner<Integer> spinner = new Spinner<>(valueFactory);
        spinner.setEditable(true);
        spinner.setMaxWidth(70);
        return spinner;
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

}// end flightSearch class