/*
Written by Mimi
Modified by Mirna & Mimi
 */

package com.example.guiplane;

import javafx.scene.control.Alert;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Random;
import java.util.Set;


public class FlightReservation {
    private static final String RESERVATION_CSV_FILE_PATH = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/reservations.csv";
    private static final String FLIGHTS_CSV_FILE_PATH = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/flights.csv";;
    private static final Set<String> usedConfirmationNumbers = new HashSet<>();

    public static void reserveFlight(Flight selectedFlight,  FlightSearch flightSearch) {
        // Generate a unique confirmation number
        String confirmationNumber = generateConfirmationNumber();

        PassengerCounts passengerCounts = flightSearch.getPassengerCounts();

        int totalTicketsSold = passengerCounts.getAdultCount() + passengerCounts.getTeensCount() +
                passengerCounts.getChildrenCount();

        // Display a confirmation message.
        String confirmationMessage = "Flight reserved!\n"
                + "\nConfirmation Number: " + confirmationNumber + "\n"
                + "Flight ID: " + selectedFlight.getFlightID() + "\n"
                + "Source: " + selectedFlight.getSource() + "\n"
                + "Destination: " + selectedFlight.getDestination() + "\n"
                + "Departure Date: " + selectedFlight.getDepartureDate() + "\n"
                + "Departure Time: " + selectedFlight.getDepartureTime() + "\n"
                + "Arrival Date: " + selectedFlight.getArrivalDate() + "\n"
                + "Arrival Time: " + selectedFlight.getArrivalTime() + "\n"
                + "Price per ticket: $" + selectedFlight.getPrice() + "\n"
        + "\nThank you for choosing to fly with us! If you would like to make any modifications to your reservation, please feel free to visit the change/cancel tab on our main page.";

        writeFlightsToCSV(selectedFlight, confirmationNumber, totalTicketsSold);

        showAlert("Reservation Confirmation", confirmationMessage, Alert.AlertType.INFORMATION);

        sendConfirmationEmail("mirnakarin2@gmail.com", "Flight Reservation Confirmation", confirmationMessage);

        flightSearch.getPrimaryStage().close();
    }
    static void sendConfirmationEmail(String recipient, String subject, String messageBody) {
        final String username = "flywithus31@gmail.com";
        final String appPassword = "czhvgpsvyygdihst ";

        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, appPassword);
            }
        });

        try {

            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress("flywithus31@gmail.com", "FlyWithUs"));


            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));

            message.setSubject(subject);
            message.setText(messageBody);

            Transport.send(message);

            System.out.println("Email sent successfully!");
        } catch (MessagingException | UnsupportedEncodingException e) {
            e.printStackTrace();
            System.out.println("Error sending email.");
        }
    }

    private static PassengerCounts getPassengerCounts(FlightSearch flightSearch) {
        return flightSearch.getPassengerCounts();
    }
    public static void writeFlightsToCSV(Flight flight, String confirmationNumber, int totalTicketsSold) {
        try (FileWriter writer = new FileWriter(RESERVATION_CSV_FILE_PATH, true)) {
            // Append flight details to the CSV file
            writer.append(confirmationNumber).append(",")
                    .append(flight.getFlightID()).append(",")
                    .append(flight.getSource()).append(",")
                    .append(flight.getDestination()).append(",")
                    .append(flight.getDepartureDate().toString()).append(",")
                    .append(String.valueOf(flight.getDepartureTime())).append(",")
                    .append(flight.getArrivalDate().toString()).append(",")
                    .append(flight.getArrivalTime().toString()).append(",")
                    .append(String.valueOf(flight.getPrice())).append(",")
                    .append(String.valueOf(totalTicketsSold)).append("\n");

            // Update the set of used confirmation numbers
            usedConfirmationNumbers.add(confirmationNumber);

            System.out.println("Flight written to CSV file successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Error saving flight to CSV file.", Alert.AlertType.ERROR);
        }
    }
    static String generateConfirmationNumber() {
        // Makes a random confirmation number that is not already used
        Random random = new Random();
        String confirmationNumber;
        do {
            confirmationNumber = String.format("%04d", random.nextInt(10000));
        } while (usedConfirmationNumbers.contains(confirmationNumber));

        return confirmationNumber;
    }
    private static void showAlert(String title, String content, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

}