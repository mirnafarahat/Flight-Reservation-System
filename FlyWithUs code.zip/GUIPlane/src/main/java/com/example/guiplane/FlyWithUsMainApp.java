/*
Written by Mirna
Modified by Mirna & Mimi
 */

package com.example.guiplane;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FlyWithUsMainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("FlyWithUs - Home");

/**************************** Home tab Start ************************************/
        Image backgroundImage = new Image("https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&q=80&w=2674&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, new BackgroundSize(100, 100, true, true, true, true));
        Background backgroundStyle = new Background(background);

        TabPane tabPane = new TabPane();

        Tab homeTab = new Tab("Home");
        Tab flightsTab = new Tab("Flights");
        Tab changeCancelTab = new Tab("Change/Cancel");

        tabPane.getTabs().addAll(homeTab, flightsTab, changeCancelTab);
        tabPane.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);

        Text companyName = new Text("FlyWithUs");
        companyName.setFont(Font.font("Brush Script MT", 80));
        companyName.setStyle("-fx-fill: white;");

        HBox companyBox = new HBox(companyName);
        companyBox.setAlignment(Pos.TOP_LEFT);
        companyBox.setStyle("-fx-background-color: rgba(0, 0, 0, 0.5);");
/***************************** Home tab end*************************************/

/*****************************Flights tab Start***********************************/
        VBox flightsLayout = new VBox();
        flightsLayout.setAlignment(Pos.CENTER);
        ScrollPane flightsScrollPane = new ScrollPane(flightsLayout);

        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            // selected tab is the "Flights" tab
            if (newValue == flightsTab) {
                //calls FlightSearch and call its start method
                FlightSearch flightSearch = new FlightSearch();
                flightSearch.start(new Stage());
            } else if (newValue == changeCancelTab) {
                //  Calls ReservationManager and call its start method
                ReservationManager reservationManager = new ReservationManager();
                reservationManager.start(new Stage());
            }
        });

        ChoiceBox<Object> tripTypeChoice = new ChoiceBox<>();
        tripTypeChoice.getItems().addAll("Round Trip", "One Way");
        tripTypeChoice.setValue("Round Trip");

        BorderPane layout = new BorderPane();
        layout.setTop(tabPane);
        layout.setCenter(companyBox);

        flightsTab.setContent(flightsScrollPane);
        changeCancelTab.setContent(new ScrollPane(new VBox()));

        layout.setBackground(backgroundStyle);
        Scene scene = new Scene(layout, 800, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /*************************** Flight tab end****************************************/

    public static void main(String[] args) {
        launch(args);
    }
}