/*
//Written by Mirna
//Modified by Mirna
 */

package com.example.guiplane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static com.example.guiplane.FlightReservation.sendConfirmationEmail;

public class ReservationManager extends Application {

    private static final String RESERVATION_CSV_FILE_PATH = "C:/Users/mirna/IdeaProjects/GUIPlane/src/main/java/com/example/guiplane/reservations.csv";
    private ToggleGroup actionGroup;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Change/Cancel");

        flightSearchAndDisplay(primaryStage);
        flightReservation(primaryStage);

        Label promptLabel = new Label("Enter Confirmation Number:");

        TextField inputField = new TextField();
        inputField.setPromptText("Enter Confirmation Number");

        TextArea outputTextArea = new TextArea();
        outputTextArea.setEditable(false);
        outputTextArea.setWrapText(true);

        Button okButton = new Button("OK");
        okButton.setOnAction(event -> {
            String userInput = inputField.getText().trim();
            searchAndDisplayFlight(userInput, outputTextArea, primaryStage);
        });
        VBox layout = new VBox(10);
        layout.getChildren().addAll(promptLabel, inputField, okButton, outputTextArea);

        Scene scene = new Scene(layout, 400, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private void searchAndDisplayFlight(String userInput, TextArea outputTextArea, Stage primaryStage) {
        try (BufferedReader br = new BufferedReader(new FileReader(RESERVATION_CSV_FILE_PATH))) {
            String line;
            boolean found = false;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 10 && (parts[0].trim().equals(userInput) || parts[9].trim().equals(userInput))) {
                    // Display flight information
                    outputTextArea.setText("Flight ID: " + parts[1] + "\n"
                            + "Source: " + parts[2] + "\n"
                            + "Destination: " + parts[3] + "\n"
                            + "Departure Date: " + parts[4] + "\n"
                            + "Departure Time: " + parts[5] + "\n"
                            + "Arrival Date: " + parts[6] + "\n"
                            + "Arrival Time: " + parts[7] + "\n"
                            + "Price: $" + parts[8] + "\n"
                            + "Number of tickets: " + parts[9] + "\n");
                    found = true;
                    break;
                }
            }
            if (found) {
                askForAction(userInput, outputTextArea, primaryStage);
            } else {
                outputTextArea.setText("No flight found for the provided Confirmation Number.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            outputTextArea.setText("Error reading reservation details.");
        }
    }
    private String getSelectedAction(ToggleGroup actionGroup) {
        RadioButton selectedRadioButton = (RadioButton) actionGroup.getSelectedToggle();
        if (selectedRadioButton != null) {
            return selectedRadioButton.getText();
        }
        return null;
    }
    private void askForAction(String userInput, TextArea outputTextArea, Stage primaryStage) {
        ToggleGroup actionGroup = new ToggleGroup();

        RadioButton changeRadioButton = new RadioButton("Change Flight");
        RadioButton cancelRadioButton = new RadioButton("Cancel Flight");

        changeRadioButton.setToggleGroup(actionGroup);
        cancelRadioButton.setToggleGroup(actionGroup);

        Button confirmButton = new Button("Confirm");
        confirmButton.setOnAction(event -> {
            String selectedAction = getSelectedAction(actionGroup);
            if (selectedAction != null) {
                outputTextArea.appendText("\n\nAction Selected: " + selectedAction);

                if ("Change Flight".equals(selectedAction)) {
                    changeFlight(userInput, outputTextArea, primaryStage);
                } else if ("Cancel Flight".equals(selectedAction)) {
                    cancelFlight(userInput, outputTextArea, primaryStage);
                }
                ((Stage) confirmButton.getScene().getWindow()).close();
            }
        });
        VBox actionLayout = new VBox(10);
        actionLayout.getChildren().addAll(new Label("Select Action:"), changeRadioButton, cancelRadioButton, confirmButton);

        Stage actionStage = new Stage();
        actionStage.setTitle("Select Action");
        actionStage.setScene(new Scene(actionLayout, 300, 200));
        actionStage.show();
    }
    private void performAction(String selectedAction, String userInput, TextArea outputTextArea, Stage primaryStage) {
        if ("Change Flight".equals(selectedAction)) {
            changeFlight(userInput, outputTextArea, primaryStage);
        } else if ("Cancel Flight".equals(selectedAction)) {
            cancelFlight(userInput, outputTextArea, primaryStage);
        }
    }
    private void cancelFlight(String confirmationNumber, TextArea outputTextArea, Stage primaryStage) {
        Path filePath = Paths.get(RESERVATION_CSV_FILE_PATH);

        try {
            List<String> lines = Files.readAllLines(filePath);
            boolean flightCancelled = lines.removeIf(line -> line.startsWith(confirmationNumber + ","));

            if (flightCancelled) {
                Files.write(filePath, lines);
                showNotification("Flight Canceled", "Flight successfully canceled!");

                // Send cancellation confirmation email
                sendCancellationConfirmationEmail("mirnakarin2@gmail.com", "Flight Cancellation Confirmation", confirmationNumber);
            } else {
                outputTextArea.setText("No flight found for the provided Confirmation Number.");
            }
        } catch (IOException e) {
            e.printStackTrace();
            outputTextArea.setText("Error canceling the flight. Please try again.");
        } finally {
            primaryStage.close();
        }
    }


    private String getCancelledFlightDetails(String confirmationNumber) {
        StringBuilder flightDetails = new StringBuilder();

        try (BufferedReader br = new BufferedReader(new FileReader(RESERVATION_CSV_FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 10 && parts[1].trim().equals(confirmationNumber)) {
                    // Format flight details for the email
                    flightDetails.append("Flight ID: ").append(parts[1]).append("\n")
                            .append("Source: ").append(parts[2]).append("\n")
                            .append("Destination: ").append(parts[3]).append("\n")
                            .append("Departure Date: ").append(parts[4]).append("\n")
                            .append("Departure Time: ").append(parts[5]).append("\n")
                            .append("Arrival Date: ").append(parts[6]).append("\n")
                            .append("Arrival Time: ").append(parts[7]).append("\n")
                            .append("Price: $").append(parts[8]).append("\n")
                            .append("Number of tickets: ").append(parts[9]).append("\n");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
            return "Hello,\n" +
                    "\n" +
                    "We hope this message finds you well. We wanted to let you know that we've received your request to cancel your flight. We understand that plans change, and we're here to assist you every step of the way.\n" +
                    "\n" +
                    "Your flight with confirmation number " + confirmationNumber + " has been successfully canceled. If you have any questions or if there's anything else we can assist you with, please don't hesitate to reach out to our customer service team.\n" +
                    "\n" +
                    "We value your choice in flying with us, and we look forward to serving you on future journeys. Safe travels, and thank you for considering FlyWithUs.\n" +
                    "\n" +
                    "Best regards,\n" +
                    "FlyWithUs";
        }

    private void sendCancellationConfirmationEmail(String recipient, String subject, String confirmationNumber) {
        String flightDetails = getCancelledFlightDetails(confirmationNumber);


        sendConfirmationEmail(recipient, subject, flightDetails);
    }

    private void showNotification(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void changeFlight(String confirmationNumber, TextArea outputTextArea, Stage primaryStage) {
        Path filePath = Paths.get(RESERVATION_CSV_FILE_PATH);

        try {
            List<String> lines = Files.readAllLines(filePath);
            boolean flightCancelled = lines.removeIf(line -> line.startsWith(confirmationNumber + ","));

            if (flightCancelled) {
                Files.write(filePath, lines);
                outputTextArea.appendText("\nFlight successfully canceled!");
                flightSearchAndDisplay(primaryStage);
            } else {
                outputTextArea.setText("No flight found for the provided Confirmation Number.");
            }

        } catch (IOException e) {
            e.printStackTrace();
            outputTextArea.setText("Error canceling the flight. Please try again.");
        }
    }
    private void flightSearchAndDisplay(Stage primaryStage) {
        FlightSearch flightSearch = new FlightSearch();
        flightSearch.start(primaryStage);
    }

    private void flightReservation(Stage primaryStage) {
        FlightReservation flightReservation = new FlightReservation();

    }


    }
